﻿/*
 *  (statusMaster.js)
 * Copyright 2012 Baidu Inc. All rights reserved.
 * 
 * @file:   statusMaster是一个用于统计前端用户行为的工具
 * @author: gengpeng@baidu.com
 */

(function () {
    //暴露给全局的对象 ,可以修改不能与已有全局变量发生冲突
    var MASTER_NAME = 'statusMaster';

    /**
    * @namespace master 
    * 功能对象 用来用户配置参数和服务器的发送参数
    */
    var master = {
        //发送到服务器的参数
        param: {},
        
        //配置参数
        config: {
            //默认的server地址
            serverUrl: 'http://10.81.58.74:8080/ubm/commonHandler.action',
            //事件类型的数组
            event: ['click'],
            //自定义的标签
            customAttr: '',
            //一个数组 
            customParam: null,
            //页面元素的标识和标识值吻合才会统计
            //标识属性
            statusKey: 'data-status',
            //标识值 
            statusValue: 'true',//标识属性
            //排除统计的标识key
            exStatusKey: '',
            //排除统计标识值 
            exStatusValue: ''
        }           
    };
    /**
    * 统计的工具函数对象封装了一些常用的
    * 
    */
    master.tools = {
        /**
         * 给浏览器添加事件动作，elm元素本身，evType事件类型，fn要执行的函数
         * @param {HTMLElement}  elm 需要注册事件的html元素
         * @param {string} evType 事件类型
         * @param {Function(Oject)} 处理事件的方法
         */
        addEvent: function (elm, evType, fn) {
            if (elm.addEventListener) {
                elm.addEventListener(evType, fn);
                return true;
            } 
            else if (elm.attachEvent) {
                var r = elm.attachEvent('on' + evType, fn);
                return r;
            } 
            else {
                elm['on' + evType] = fn;
            }
        },

        /**
         * 获取事件的源头
         * @param {Object} e 浏览器事件参数
         * @return {HTMLElement}  返回触发事件的html元素
         */
        getTarget: function (e) {
            var e = e || window.event;
            var target = e.srcElement || e.target;
            if (!target) {
                return false;
            }
            //for safari
            while (
                target.nodeType != 1 
                && target.nodeName.toLowerCase() != 'body') {

                target = target.parentNode;
            }
            return target;
        },
    
        /**
         * 得到不重复的标识
         * @return {string} 返回不重复字符串
         */
        unique: function() {
            var i = 0;
            return function () {
                var time= (new Date()).getTime() + '_';
                return time + i++;
            }
        }(),               

        /**
         * 获取鼠标 相对于屏幕的位置
         * @param {Object} e 事件对象
         * @return {Object}  事件触发元素的x和y的坐标
         */
        getMousePos: function(e) {
            var e = e || window.event;
            return {
                x: e.clientX,
                y: e.clientY
            }
        },

        /**
        * 将json对象序列化串
        * @param {Object} obj 传入需要序列化的对象
        * @return {string} 返回json对象序列
        */

        stringify: function(obj) {

            return stringify(obj);

            //parse to string
            function stringify(O) {
                var S = [];
                var J = "";
                var oType = Object.prototype.toString.apply(O);
                if (oType === '[object Number]') {
                    J = O;
                }
                else if (oType === '[object String]') {
                    J = '"' + O + '"';
                } 
                else if (oType === '[object Date]') {
                    J = '"' + O.getFullYear() + ( O.getMonth()+1) + O.getDate() + '"';
                } 
                else if (oType === '[object RegExp]') {
                    J = O.toString();
                } 
                else if ( oType === '[object Array]') {
                    for (var i = 0; i < O.length; i++)
                    S.push(stringify(O[i]));
                    J = '[' + S.join(',') + ']';
                } 
                else if (oType === '[object Object]') {
                    for (var key in O) {
                        var obj = O[key],
                        t = typeof (obj);
                        obj = stringify(obj);
                        S.push( '"' + key + '":' + obj);
                    }
                    J = '{' + S.join(',') + '}';
                }
                return J;
            
            }
            
        },

        /**
        * 简单的参数接收工具
        * @param {Object} destination 目标对象
        * @param {Object} source 源对象
        * @return {Object}  接受参数后的对象
        */
        extend: function(destination, source) {
            source = source || {};
            for (var property in source) {
                destination[property] = source[property];
            } 
            return destination;
        }
       
    };

    /**
     *  参数管理器
     *
     */
    master.paramManager = function() {
        var me = master;
        /**
        * cache相关的对象，
        */
        var cache = {
            lastTime: 123,
            param: {},
            setLastTime: function(t) {
                this.lastTime = t; 
            },
            checkMinTime: function(t) {
                return  t - this.lastTime > 500 ? true : false;              
            }
        };
        var param = me.param || {};
        var tools = me.tools;
        var config = me.config;
        var setParam = function(target, e, eventName ) {
            var pos = tools.getMousePos(e);
            var target = target || tools.getTarget(e);
            var p = param;

            p.evt = eventName;   
            p.x = pos.x;
            p.y = pos.y;
            p.tag = target && target.tagName && target.tagName.toLowerCase(); 
            p.ref = document.location.href;
            //p.uid = config.uid || '';
            //标签id
            p.eid = function(target) {
                var cAttr = config.customAttr || '';
                var value = '';
                if (cAttr) {
                    value = target.getAttribute(cAttr) || '';
                }

                return value;
            }(target);
            //p.app = config.appName || '';
            p.t = (new Date()).getTime() + '';
            //用户附件的属性
            p.cp = config.customParam || null;
            if (p.cp === null) {
                delete p.cp; 
            }
            return p;
        }; 
        /**
        * 转化json 
        * @param {Object} param 参数对象
        * @return {string} 返回的参数字符串
        */
        var parseParam = function(param) {
            
            var str = tools.stringify(param); 
            //uid和app需要单独提取为参数
            str =  encodeURIComponent(str);
            str += '&uid=' + encodeURIComponent(config.uid);
            str += '&app=' + encodeURIComponent(config.appName);
            return str;
                    
        };
        /**
        * 发送日志msg
        * @param {Object} obj 直接push的参数对象
        */
        var pushLog = function(obj) {
           var str = parseParam (obj);
           sendParam(str);
        };
        /**
        * 发送特定url到服务器，并销毁回调和自身引用
        * @param {string} param 字符串参数
        *
        */
        var sendParam = function(param) {
            var t =  new Date().getTime();
            var url = config.serverUrl;  
            var unique = tools.unique; 

            url += '?msg=' + param; 
            imgLog(url);
            //send url
            function imgLog(url) {
                var data = window['_crmStatusLogData__'] || (window['_crmStatusLogData__'] = {});
                var img = new Image();
                var uid = unique();
                data[uid] = img.onload = img.onerror = function () {//销毁一些对象
                    img.onload = img.onerror = null;
                    img = null;
                    delete data[uid];
                }
                img.src = url + '&rnd=' + uid;
            };       
        };
        
        /**
        * 检测是有发送log的条件
        * @return {boolean}  检测是否可以发送log
        */
        var check = function() {
            var t = new Date().getTime();
            if (cache.checkMinTime(t)) {
                cache.setLastTime(t);
                return true; 
            } 
            else {
                return false;
            }
        };

        //处理 参数
        var handleParam = function(target, e, eventName) {
            var objParam = setParam(target, e, eventName);

            var strParam = parseParam(objParam);
            
            if( check()) {
            //发送
                sendParam(strParam);
            }

        };
        //处理 参数, 增加用户自定义的属性
        var handleCustomParam = function(target, e, eventName, customParam) {
            var objParam = setParam(target, e, eventName);
            //XXX:因为后台没有解析嵌套的obj，所以修改一下 转为字符串
            //目前先转为string类型的
            if (customParam) {
                objParam.customParam = 'custom' || tools.stringify(customParam); 
            }
            var strParam = parseParam(objParam);
            if (check()) {
                //发送
                sendParam(strParam);
            }
            //清楚原来的参数
            param.customParam = null;
            delete param.customParam;
        };
         
        return {
            handleParam: handleParam,
            handleCustomParam: handleCustomParam,
            pushLog: pushLog
        } 
    
    }();
 
   /**
    *  事件管理
    */
    master.eventManager = function() {
        var me = master;
        var tools = me.tools,
            config = me.config,
            addEvent = tools.addEvent,
            param = me.param,
            //事件的名称和 对应的事件注册 
            eventDic = {
                click: clickFn,
                mousedown: '0',
                mouseup: '0',
                blur: '0',
                focus: '0'
            };

        //注册事件 传入config 参数
        var init = function(_config) {
            var config = _config || config;
            var events = config.event || ['click'];
            
            for(var item, i = 0; item = events[i]; i++) {
                if (typeof (eventDic[item]) === 'function') {
                    eventDic[item]();
                } 
            }
        };
        /**
         * 过滤属性 需要传入事件的对象
         * @param {Object} target 事件的html元素
         */
        var filter = function(target) {
            var config = master.config;
            var filters = {
                getValueType: function(value) {
                    var str = Object.prototype.toString.call(value); 
                    var dic = {
                        '[object String]': "str",
                        '[object Number]': "num",
                        '[object RegExp]': "reg" 
                    }
                    return dic[str];
                },
                //必须包含的属性
                include: function(target) {
                    
                    var statusKey = config.statusKey || '';
                    var statusValue = config.statusValue || '';
                    var eleValue = target.getAttribute(statusKey);
                    var result = false;
                    var type = this.getValueType(statusValue);
                    if (type === 'reg') {
                        result =  (eleValue && eleValue.test(statusValue));
                    } 
                    else if (type === 'str' ) {
                        result = (eleValue && (eleValue === statusValue));
                    }

                    return result;
                },
                /**
                * 不包含的内容属性
                 */
                exclude: function(target) {
                    var statusKey = config.exStatusKey || '';
                    var statusValue = config.exStatusValue || '';
                    var eleValue = target.getAttribute(statusKey);
                    if(eleValue && eleValue === statusValue) {
                        return false;
                    } 
                    else {
                        return true; 
                    }       
                }
            }; 
            var test = function(target) {
                var re = filters.include(target); 
                var re2 = filters.exclude(target); 
                return !!(re & re2);
            }

           return {
               test: test,  
               getValueType: filters.getValueType
           } 
            
        }();

        /**
         *  点击事件处理函数
         *  @type event
         */
        function clickFn() {
            var getPos =  tools.getMousePos;
            var getTarget = tools.getTarget;
            //注册事件
            addEvent(document, 'click', function(e) {
                var target =  getTarget(e);
                var pos = getPos(e);
                //检测是否发送log日志：过滤属性
                if (filter.test(target)) {
                    //处理 对象 解析成参数
                    me.paramManager.handleParam(target, e, 'click');
                } 
            })  
        }
        //暴露给外部的方法 用来主动pushEvent
        var _pushEvent = function(target, e, eventName, customParam) {
        
            me.paramManager.handleCustomParam(target, e, eventName, customParam);
        } 
        //给不方便的元素 注册监听事件 
        var _addEvent = function(ele, eventName) {
            addEvent(ele, eventName, function(e) {
                var e = e || window.event; 
                me.paramManager.handleParam(ele, e, eventName);

            });
        }
        return {
            init: init,
            pushEvent: _pushEvent,
            addEvent: _addEvent
        }
    }();

    /**
     * 初始化统计工具
     * @param {Object} obj 传入的配置参数
     * @param {string} obj.serverUrl 服务器地址
     * @param {Array} obj.event 监控的事件的类型集合
     * @param {string} obj.customAttr html元素的属性，用来作为log元素的标识
     * @param {string} obj.statusKey 需要监控的元素筛选属性
     * @param {string} obj.statusValue 需要监控的元素筛选值 
     * @param {string=} obj.exStatusKey 需要监控的元素筛选值 
     * @param {string=} obj.exStatusValue 需要监控的元素筛选值 
     * @param {string} obj.uid  用户的id
     * @param {string} obj.appName  项目的名称了
     */
    var init = function(obj) {
        var obj = obj || {};
        var config = master.config;
        config = master.tools.extend(config, obj);

        master.eventManager.init(config);
    };

    /**
    * 获取兼容系统配置的参数
    * @return {Object} obj 获取系统的配置参数
    * @return {string} obj.serverUrl 服务器地址
    * @return {Array} obj.event 监控的事件的类型集合
    * @return {string} obj.customAttr html元素的属性，用来作为log元素的标识
    * @return {string} obj.statusKey 需要监控的元素筛选属性
    * @return {string} obj.statusValue 需要监控的元素筛选值 
    * @return {string=} obj.exStatusKey 需要监控的元素筛选值 
    * @return {string=} obj.exStatusValue 需要监控的元素筛选值 
    * @return {string} obj.uid  用户的id
    * @return {string} obj.appName  项目的名称
    */
    var getConfig = function() {
        return  master.config;
    }


    /**
    * 主动发送基于事件的log，ecui没用原生的click，监听了mousedown up，因此
    * 在ecui的事件处理中，可以主动将mouseDown事件 改成click名称，
    * 并且支持自定义参数，方便统计
    * @param {Object} traget 触发事件的元素
    * @param {Object} e 触发事件的元素参数
    * @param {string} eventName 触发事件的名称 click, mouseup
    * @param {Object} customParam 发送log的任意参数对象
    */
    var pushEvent = master.eventManager.pushEvent; 

    /**
    * 给元素注册监控事件，主要是解决有时候一些元素会取消事件冒泡，
    * 使得body处无法获取事件，所以需要给这些元素注册监听事件
    * @param {Object} ele 需要监听的html元素
    * @param {string} event 需要监听的html元素触发事件名称 eg: click...
    */
    var addEvent = master.eventManager.addEvent;

    /**
    * 主动推送log信息{Object}，有些时候 就想随意发送log
    * 比如页面初始化 或者 。。监控用户鼠标轨迹。。。
    * XXX：需要注意的是obj最多包含基本类型，不能嵌套Object对象(后台不支持。。。)
    * @param {Object} obj 随意的obj参数
    */
    var pushLog = master.paramManager.pushLog;

    //暴露给全局变量 详细参数参考楼上
    window[MASTER_NAME] = {
        init: init ,
        getConfig: getConfig,
        pushEvent: pushEvent,
        addEvent: addEvent,
        pushLog: pushLog
    };

})();
